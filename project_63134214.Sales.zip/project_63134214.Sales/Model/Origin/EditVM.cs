﻿namespace Sales.Model.Origin
{
	public class EditVM
	{
		public Guid id { get; set; }

		public string? OriginName { get; set; }

	}
}

﻿namespace Sales.Model.Origin
{
	public class CreateVM
	{
		public string? OriginName { get; set; }

	}
}

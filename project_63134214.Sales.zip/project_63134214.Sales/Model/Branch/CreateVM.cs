﻿namespace Sales.Model.Branch
{
	public class CreateVM
	{
		public string? BranchName { get; set; }
	}
}

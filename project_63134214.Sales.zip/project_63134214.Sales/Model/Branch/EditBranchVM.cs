﻿namespace Sales.Model.Branch
{
	public class EditBranchVM
	{
		public string? BranchName { get; set; }
		//public List<IFormFile>? ListFileImg { get; set; }
	}
}

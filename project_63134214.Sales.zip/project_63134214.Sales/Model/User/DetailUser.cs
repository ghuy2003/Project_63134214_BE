﻿namespace Sales.Model.User
{
    public class DetailUser
    {
        public string UserId { get; set; }
    }
}

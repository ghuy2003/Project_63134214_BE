﻿namespace Sales.Model.Rate
{
	public class EditVM
	{
		public Guid? UserId { get; set; }
		public Guid? ProductId { get; set; }
		public int RateQuanlity { get; set; }
	}
}
